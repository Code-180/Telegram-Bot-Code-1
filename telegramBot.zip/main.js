//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
// Package
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
const {
    Bot
} = require('grammy');
require('dotenv').config()
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
const bot = new Bot(process.env.SECRET_BOT_KEY);
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
// bot.command("start", (ctx) => ctx.reply("Welcome! To Code-180 Tutorial."));
// bot.command("end", (ctx) => ctx.reply("Buy."));
// bot.hears('Hello-180', (ctx) => ctx.reply('Like And Subscribe'));
// bot.hears('Hello', (ctx) => ctx.reply('Like And Subscribe'));
bot.on("message", (ctx) => {
    const message = ctx.message.text;
    console.log(message);
    ctx.reply(message);
});
bot.on('message:text', (ctx) => ctx.reply(`Greeting "${ctx.update.message.text}" is not supported.`))
bot.on(":text"); // any text messages and any text post of channels
// bot.on('message:photo', (ctx) => ctx.reply(ctx))
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
// bot.on("message"); // called when any message is received
// bot.on("message:text"); // only text messages
// bot.on("message:photo"); // only photo messages
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
// bot.on("message:entities:url"); // messages containing a URL
// bot.on("message:entities:code"); // messages containing a code snippet
// bot.on("edited_message:entities"); // edited messages with any kind of entities
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
// bot.on(":text"); // any text messages and any text post of channels
// bot.on("message::url"); // messages with URL in text or caption (photos, etc)
// bot.on("::email"); // messages or channel posts with email in text or caption
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
bot.start();